# skin.titan.bingie.mode
bingie mode for Kodi skin Titan

WORK-IN-PROGRESS (beta stage)

BIG THANKS to @marcelveldt for his work on the original code for Titan skin & addons
https://github.com/marcelveldt
