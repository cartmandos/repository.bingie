# skin.titan

This skin's stable version is available in the official Kodi repository.

## Beta version repository
If you want to try out the latest features you can install my beta repository:

https://marcelveldt.github.io/repository.marcelveldt/repository.marcelveldt/repository.marcelveldt-1.0.1.zip

 
PLEASE DO NOT INSTALL THE SKIN DIRECTLY FROM GITHUB, I WILL NOT PROVIDE SUPPORT !
USE OFFICIAL VERSION FROM KODI REPO OR THE BETA VERSION FROM MY REPO ONLY!


## Help needed with maintaining !
I am very busy currently so I do not have a lot of time to work on this project or watch the forums.
Be aware that this is a community driven project, so feel free to submit PR's yourself to improve the code and/or help others with support on the forums etc. If you're willing to really participate in the development, please contact me so I can give you write access to the repo. I do my best to maintain the project every once in a while, when I have some spare time left.
Thanks for understanding!
